There are 3 files:

1) ipython notebook(Association Rule Mining in Retail Store.ipynb) contains codes.

2) raw_bread.xlsx dataset used in ipython notebook.

3) word file(final_blog.docx) contain article draft.